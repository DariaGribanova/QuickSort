package ru.vsu.gribanova;

import java.util.Arrays;
import java.util.Random;

public class Main {

	public static long k = 0;

    public static void main(String[] args) {
		Random rnd = new Random();
		int[] arr = new int[100];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = rnd.nextInt(10000);
		}
		sort(arr);
		Arrays.sort(arr);
		System.out.println("Проверка на отсортированном массиве:");
		sort(arr);
	}

	public static void sort(int[] arr) {
		for (int n = 1; n<5; n++) {
			int[] arr1 = arr.clone();
			quickSort(arr1, 0, arr1.length - 1, n);
			System.out.print("Опорный элемент: ");
			if (n ==1 ){
				System.out.println("Первый");
			};
			if (n == 2 ){
				System.out.println("Последний");
			};
			if (n == 3 ){
				System.out.println("Случайный");
			};
			if (n == 4 ){
				System.out.println("Медиана");
			};
			System.out.println("Количество сравнений:" + k);
			k = 0;
		}
	}

	public static void quickSort(int[] arr, int l, int r, int n) {
		if (l >= r) return;
		int j = partition(arr, l, r, n);
		quickSort(arr, l, j - 1, n);
		quickSort(arr, j + 1, r, n);
	}

	private static int choosePivot(int[] arr, int n, int l, int r) {
		if (n == 1) return l;
		else if (n == 2) return r;
		else if (n == 3) return (int)(Math.random()* (r - l +1)) + l;
		else if (n == 4) {
			int x = arr[l];
			int y = arr[(l + r) / 2];
			int z = arr[r];
			if ((x >= y && y >= z) || (x <= y && y <= z))
				return (l + r) / 2;
			else if ((x >= z && z >= y) || (x <= z && z <= y))
				return r;
			else return l;
		}
		return l;
	}

	public static int partition(int[] arr, int l, int r, int n) {
		int p = choosePivot(arr, n, l, r);
		int pv = arr[p];
		swap(arr, p, r);
		int j = l;
		for (int i = l; i <= r; i++) {
			k++;
			if (arr[i] < pv) {
				swap(arr, j, i);
				j++;
			}
		}
		swap(arr, r, j);
		return j;
	}

	public static void swap(int[] arr, int f, int s) {
		int x = arr[f];
		arr[f] = arr[s];
		arr[s] = x;
	}
}
